const socketIo = require('socket.io');
const Game = require('./models/Game');

module.exports = (server) => {
    const io = socketIo(server);

    io.on('connection', (socket) => {
        console.log('New client connected');

        socket.on('joinRoom', async ({ roomId, username }) => {
            socket.join(roomId);
            const game = await Game.findOne({ roomId });
            if (game) {
                game.players.push(username);
                await game.save();
                io.to(roomId).emit('updateGame', game);
            }
        });

        socket.on('makeGuess', async ({ roomId, letter }) => {
            const game = await Game.findOne({ roomId });
            if (game) {
                if (game.word.includes(letter)) {
                    game.guesses.push(letter);
                } else {
                    game.incorrectGuesses += 1;
                }
                await game.save();
                io.to(roomId).emit('updateGame', game);
            }
        });

        socket.on('disconnect', () => {
            console.log('Client disconnected');
        });
    });

    return io;
};
