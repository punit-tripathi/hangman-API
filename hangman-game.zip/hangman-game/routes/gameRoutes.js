const express = require('express');
const gameController = require('../controllers/gameController');
const router = express.Router();

router.post('/createRoom', gameController.createRoom);
router.post('/joinRoom', gameController.joinRoom);
router.post('/makeGuess', gameController.makeGuess);

module.exports = router;
