const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const gameRoutes = require('./routes/gameRoutes');
const socketSetup = require('./socket');

const app = express();
const server = http.createServer(app);
const io = socketSetup(server);

mongoose.connect('mongodb://localhost:27017/hangman');

app.use(bodyParser.json());
app.use('/auth', authRoutes);
app.use('/game', gameRoutes);

server.listen(3001, () => {
    console.log('Server is running on port 3001');
});
