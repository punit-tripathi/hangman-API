const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
    roomId: { type: String, required: true, unique: true },
    word: { type: String, required: true },
    guesses: { type: [String], default: [] },
    incorrectGuesses: { type: Number, default: 0 },
    turn: { type: String, required: true },
    players: { type: [String], required: true },
});

module.exports = mongoose.model('Game', gameSchema);
