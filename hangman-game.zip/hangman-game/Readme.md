# HangOut & Hangman: Where Words Connect

## Overview

This project is a multiplayer Hangman game built with Node.js, Express, MongoDB, and Socket.io for real-time communication. Players can create and join game rooms, and take turns guessing letters in a classic Hangman setup.

## Features

- User Authentication (registration and login)
- Create and join game rooms
- Real-time updates via WebSockets
- Word validation using an external dictionary API

## Technologies Used

- Node.js
- Express
- MongoDB
- Socket.io
- bcrypt
- JWT

# API Endpoints

Authentication
POST /auth/register

Request: { "username": "user", "password": "pass" }
Response: { "message": "User registered successfully" }
POST /auth/login

Request: { "username": "user", "password": "pass" }
Response: { "token": "jwt_token" }
Game
POST /game/createRoom

Request: { "roomId": "room1", "players": ["user1"], "word": "example" }
Response: { "message": "Game room created successfully", "game": { ... } }
POST /game/joinRoom

Request: { "roomId": "room1", "username": "user2" }
Response: { "message": "Joined room successfully", "game": { ... } }
POST /game/makeGuess

Request: { "roomId": "room1", "letter": "e" }
Response: { "message": "Guess recorded", "game": { ... } }
WebSocket Events
joinRoom

Payload: { "roomId": "room1", "username": "user1" }
Joins the user to the specified room and broadcasts the updated game state.
makeGuess

Payload: { "roomId": "room1", "letter": "e" }
Makes a guess for the current game and broadcasts the updated game state.



# **Start MongoDB**

   Make sure your MongoDB server is running. You can start it using the following command:

   ```bash
   mongod
