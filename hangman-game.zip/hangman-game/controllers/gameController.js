const Game = require('../models/Game');
const dictionaryAPI = require('../utils/dictionaryAPI');

exports.createRoom = async (req, res) => {
    const { roomId, players, word } = req.body;
    try {
        const game = new Game({ roomId, players, word, turn: players[0] });
        await game.save();
        res.status(201).send({ message: 'Game room created successfully', game });
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
};

exports.joinRoom = async (req, res) => {
    const { roomId, username } = req.body;
    try {
        const game = await Game.findOne({ roomId });
        if (!game) {
            return res.status(404).send({ error: 'Room not found' });
        }
        game.players.push(username);
        await game.save();
        res.send({ message: 'Joined room successfully', game });
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

exports.makeGuess = async (req, res) => {
    const { roomId, letter } = req.body;
    try {
        const game = await Game.findOne({ roomId });
        if (!game) {
            return res.status(404).send({ error: 'Room not found' });
        }
        if (game.word.includes(letter)) {
            game.guesses.push(letter);
        } else {
            game.incorrectGuesses += 1;
        }
        await game.save();
        res.send({ message: 'Guess recorded', game });
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};
